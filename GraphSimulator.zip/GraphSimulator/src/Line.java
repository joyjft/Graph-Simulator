
import java.awt.Color;


public class Line {
    
    public int startX,startY,endX,endY;
    Color color=Color.BLACK;

    public Line(Color color) {
        this.color = color;
    }

    public Line() {
    }
    
    
    
}
