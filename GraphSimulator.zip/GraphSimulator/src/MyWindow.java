
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;



public class MyWindow extends JFrame{

    

    
    
   public  Node root;
     Box box1;
    JButton nodeBtn,edgeBtn,rePosition,delNode,delEdge;
    Color color1,color2;
    MyCanvas canvas;
    MyCanvas2 myCanvas2;
    MyWindow myGui;
    boolean f;
    int count=1;
   static  MyWindow myWindow;
    public MyWindow()
    {
        color1=new Color(172,221,126);
        color2=new Color(66,133,244);
        super.setTitle("Graph Simulator");
        super.setPreferredSize(new Dimension(1260, 700));
        super.setResizable(true);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
       //ADD NODE BUTTON
        ImageIcon addNode = new ImageIcon(getClass().getClassLoader().getResource("images/addNode.png"));
       nodeBtn=new JButton(addNode);
       nodeBtn.setPreferredSize(new Dimension(150,44));
       nodeBtn.setBackground(new Color(172,221,126));
       nodeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                 
                canvas.flag=1;
               reSet();
                nodeBtn.setBackground(new Color(66,133,244));
                nodeBtn.setForeground(Color.WHITE);
                delEdge.setBackground(color1);
                rePosition.setBackground(new Color(172,221,126));
                  edgeBtn.setBackground(new Color(172,221,126));
                   delNode.setBackground(color1);
                
                repaint();
                
            }
        });
        
        //ADD EDGE BUTTON
       
        ImageIcon addEdge = new ImageIcon(getClass().getClassLoader().getResource("images/line_1.png"));
        edgeBtn=new JButton(addEdge);
        edgeBtn.setPreferredSize(new Dimension(150,44));
        edgeBtn.setBackground(new Color(172,221,126));
        edgeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                nodeBtn.setBackground(new Color(172,221,126));
                rePosition.setBackground(new Color(172,221,126));
                 reSet();
                delEdge.setBackground(color1);
                delNode.setBackground(color1);
                if (canvas.nodeCount<3) {
                     
                   
                    JOptionPane.showMessageDialog(myWindow, "Please Enter Atleast Two Nodes.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    
                }
                
                else{
                edgeBtn.setBackground(new Color(66,133,244));
                edgeBtn.setForeground(Color.WHITE);
                
                repaint();
                canvas.flag=2;
                Line line = new Line();
                canvas.setL(line);
                canvas.lines.add(line);
                canvas.element[canvas.elementCount++]=2;
                
                
                }
         
            }
        });
        
        
        
        
        //RE-ARRANGE BUTTON
        ImageIcon reArrange = new ImageIcon(getClass().getClassLoader().getResource("images/move.png"));
       rePosition=new JButton(reArrange);
       rePosition.setPreferredSize(new Dimension(150,44));
       rePosition.setBackground(new Color(172,221,126));
       rePosition.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if(canvas.nodes.isEmpty())
                {
                    System.out.println("mm");
                    JOptionPane.showMessageDialog(myWindow, "Graph Empty!.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    return ;

                }
                 reSet();
                rePosition.setBackground(new Color(66, 133, 244));
                rePosition.setForeground(Color.WHITE);
                delEdge.setBackground(color1);
                nodeBtn.setBackground(new Color(172, 221, 126));
                edgeBtn.setBackground(new Color(172, 221, 126));
                delNode.setBackground(color1);
                repaint();
                canvas.flag = 3;
            }
        });
       
       
       
       
       //DELETE NODE BUTTON
         delNode = new JButton(new ImageIcon(getClass().getClassLoader().getResource("images/Delete.png")));
         delNode.setPreferredSize(new Dimension(150,44));
         delNode.setBackground(color1);
         delNode.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if(canvas.nodes.isEmpty())
                {
                    
                    JOptionPane.showMessageDialog(myWindow, "Node Doesn't Exist.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    return ;
                }
                 reSet();
                delNode.setBackground(color2);
                 delNode.setForeground(Color.WHITE);
                delEdge.setBackground(color1);
                 nodeBtn.setBackground(new Color(172,221,126));
                edgeBtn.setBackground(new Color(172,221,126));
                rePosition.setBackground(color1);
                repaint();
                canvas.flag=4;
            }
        });
         
         
         
         
         
         //DELETE EDGE BUTTON
       
       delEdge = new JButton(new ImageIcon(getClass().getClassLoader().getResource("images/deleteEdge.png")));
      delEdge.setPreferredSize(new Dimension(150,44));

       delEdge.setBackground(color1);
       delEdge.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
              
                if(canvas.lines.isEmpty())
                {
                    JOptionPane.showMessageDialog(myWindow, "No Edge Found.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    return ;
                }

                reSet();
                delNode.setBackground(color1);
                delEdge.setBackground(color2);
                 delEdge.setForeground(Color.WHITE);
                 nodeBtn.setBackground(new Color(172,221,126));
                edgeBtn.setBackground(new Color(172,221,126));
                rePosition.setBackground(color1);
                repaint();
                canvas.flag=5;
            }
        });
       
       //Set Root
       JButton setRoot = new JButton("Set Root");
        setRoot.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                reSet();
                 if(canvas.nodes.isEmpty())
               {
                   JOptionPane.showMessageDialog(myWindow, "Add AtleaSt one Node.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    return ;
               }
               canvas.cf=false;
               canvas.flag=6;
            
               
                
                
            }
        });
       
       
       
       //BFS BUTTON
       
        JButton jButton = new JButton("Run BFS");
        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                 reSet();
                 canvas.flag=7;
                 canvas.drawName=false;
                 if(canvas.root==null)
               {
                   JOptionPane.showMessageDialog(myWindow, "Select Root First.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    return ;
               }
                 MyThread thread = new MyThread();
                 thread.setMyCanvas2(myCanvas2);
                 thread.setCanvas(canvas);
                 thread.setBox(box1);
                 canvas.setThread(thread);
                 thread.root=root;
                 thread.start();
                
                 
                
                
                
                
                
            }
        });
        JButton dfS = new JButton("Run DFS");
        dfS.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
              
                canvas.flag=8;
                reSet();
                 if(canvas.root==null)
               {
                   JOptionPane.showMessageDialog(myWindow, "Select Root First.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    return ;
               }
                DfSThread dfSThread = new DfSThread();
                dfSThread.setCanvas(canvas);
                dfSThread.start();
            
               
                
                
            }
        });
        
       
       //ADDING THE BUTTONS IN A PANEL AND LAYING -OUT
        JPanel jPanel = new JPanel();
        jPanel.setBackground(new Color(255,228,196));
        jPanel.setPreferredSize(new Dimension(1260,64));
        jPanel.setLayout(new GridLayout(1,0,5,4));
        jPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        jPanel.add(nodeBtn);
        jPanel.add(edgeBtn);
        jPanel.add(rePosition);
        jPanel.add(delNode);
        jPanel.add(delEdge);
        jPanel.add(setRoot);
        jPanel.add(jButton);
        jPanel.add(dfS);
        jPanel.setBorder(new EmptyBorder(4,4,4,4));
        Box box = Box.createVerticalBox();
        
        
       
       
      canvas=new MyCanvas();
      LineBorder border = new LineBorder(new Color(148,0,211), 2);
      canvas.setBorder(border);
        
      box.add(jPanel);
     box.add(Box.createVerticalStrut(2));
       myCanvas2 = new MyCanvas2();
      LineBorder border1 = new LineBorder(new Color(148,0,211), 2);
      myCanvas2.setBorder(border1);
      
      myCanvas2.setCanvas(canvas);
      myCanvas2.setWindow(myWindow);
         box1 =Box.createHorizontalBox();
        box1.add(Box.createHorizontalStrut(1));
        
        box1.add(canvas);
        box1.add(Box.createHorizontalStrut(2));
        box1.add(myCanvas2);
      
      box.add(box1);
      canvas.setGui(myWindow);
      canvas.setCanvas(canvas);
      //ADDING ALL COMPONENT TO FRAME AND PREPARING A COMPLETE WINDOW
      super.add(box);
      super.revalidate();
      super.repaint();
      super.pack();
      super.setVisible(true);
      super.setLocationRelativeTo(null);
        
    }
    
    
    
    
    
      
    public static void main(String[] args) {
        
        myWindow = new MyWindow();
    }

  
 
    public void reSet()
    {
        
        
        for(Node x: canvas.nodes)
        {
            x.color=x.defaultColor;
            x.level=-1;
            x.nameColor=Color.BLUE;
        }
        
        for(Line x: canvas.lines)
        {
            x.color=Color.BLACK;
        }
        //canvas.root=null;
        canvas.drawName = true;
        canvas.repaint();
    }
    
    
    
    
}
